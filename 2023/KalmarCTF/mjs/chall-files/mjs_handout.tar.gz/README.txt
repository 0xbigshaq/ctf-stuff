https://github.com/cesanta/mjs
diff.patch is just hardening :)
